const menu=document.querySelector('.menu-btn');const links=document.querySelector('.links');
menu?.addEventListener('click',()=>links.classList.toggle('open'));
document.querySelectorAll('.links a').forEach(a=>a.addEventListener('click',()=>links.classList.remove('open')));
document.getElementById('year').textContent=new Date().getFullYear();
document.getElementById('contactForm').addEventListener('submit',e=>{
  e.preventDefault();
  document.getElementById('formMsg').textContent='تم استلام الرسالة تجريبياً. لربط النموذج بالبريد الإلكتروني نحتاج إعداد خدمة إرسال.';
  e.target.reset();
});